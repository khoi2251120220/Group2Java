package uth.edu.auctionkoi.service;

public interface IUserService {
}
