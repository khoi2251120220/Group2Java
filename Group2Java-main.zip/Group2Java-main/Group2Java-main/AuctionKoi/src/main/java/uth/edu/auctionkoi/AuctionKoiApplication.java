package uth.edu.auctionkoi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctionKoiApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuctionKoiApplication.class, args);
    }
    
}
