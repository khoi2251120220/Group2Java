package uth.edu.auctionkoi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionKoiApplicationTests {

    @Test
    void contextLoads() {
    }

}
